# Handoff: Eradigm Competitive Intelligence Platform

## Overview
A web app for Eradigm Consulting that captures pharma competitor news, extracts a structured tracker entry with an LLM, routes every draft to human review, and publishes approved signals to a searchable tracker and analysis dashboard.

Four screens, reached from a collapsible left sidebar: **Dashboard**, **Tracker**, **Inbox**, **Input** (Input is limited to analyst/admin roles).

## About the design files
`Intelligence Dashboard.dc.html` is a **high-fidelity design reference built in HTML**. It is a working prototype that shows the intended look and behaviour; it is not production code. Recreate it in the target codebase's stack (for example React + TypeScript on Cloudflare Pages/Workers). If no codebase exists yet, choose the framework that fits best. Open the file in a browser (keep `support.js` and `assets/` beside it) to click through every screen.

The prototype's markup is inline-styled. Treat those inline values as the spec. In the real build, pull them into tokens/components (see Design tokens).

All data is mock data generated in the logic class: 78 seeded signals, 4 Inbox items and a canned LLM output. Capture and LLM calls are simulated.

## Fidelity
**High fidelity.** Match colours, type, spacing, radii and interactions exactly. The visual identity is Eradigm's own palette (teal/cyan on deep navy) with Nunito Sans. Do **not** restyle it with any other design system.

---

## Global layout
- The app shell is a flex row: sidebar + `main` (flex:1, min-width:0). Page background `#EEF3F6`.
- **Sidebar** (open): 252px wide, `#072838`, sticky, full viewport height, padding 22px 14px.
  - Logo tile: 60×60, white, radius 12, image `assets/eradigm-logo.webp` cropped (100×100 at -20,-4).
  - Wordmark "ERADIGM" in 700 21px, letter-spacing .2em. "CONSULTING" in 600 12px, .26em, `#8FB4C4`.
  - Section label "COMPETITIVE INTELLIGENCE": 600 10px, .14em, `#6F97A8`.
  - Nav items: 42px tall, radius 0 7px 7px 0, 3px left bar. Active item has bg `rgba(61,195,201,.14)`, text `#fff` and bar `#3DC3C9`. Inactive items have text `#B5CFDA`. Hover bg `rgba(255,255,255,.08)`. Inbox shows a pending-count badge: `#3DC3C9` bg, `#072838` text, IBM Plex Mono 11px, radius 10.
  - Footer: reviewer name (700 13.5px) and "{Role} · Client workspace" (12px `#8FB4C4`), above a top border `rgba(255,255,255,.12)`.
  - Close button «: 28×28, top-right. Closed state is a 48px strip holding a » button (34×34).
- **Page header band** (every screen): `linear-gradient(120deg,#0F4C66 0%,#0B3A50 55%,#082C3D 100%)`, white text, padding 30px 32px.
  - Eyebrow: 600 11px, .16em, `#7FD3D8`.
  - H1: 700 28px/1.15, uppercase copy.
- **Cards**: white, 1px `#DCE5EA`, radius 10, padding 18px 20px. Card titles are 700 14px, .08em, uppercase. Subtitles are 12.5px `#587080`.
- Content padding: 24px 32px 64px, gap 20px.

## Screens

### 1. Dashboard
- **Header**: eyebrow "APPROVED SIGNALS", H1 "INTELLIGENCE DASHBOARD", search input on the right. The search input is 360×40, radius 8, bg `rgba(255,255,255,.1)`, border `rgba(255,255,255,.28)`.
- **KPI row** (below a 1px `rgba(255,255,255,.22)` rule): auto-fit grid of minmax(170px,1fr). Each KPI shows a value (800 58px/1), a label (700 18px) and a note (14px `#B5CFDA`). The four KPIs are Approved signals, Competitors involved, High impact and Low impact.
- **Active filters card**: white, radius 10, shadow `0 6px 18px rgba(7,40,56,.16)`. It straddles the header/body border (margin-bottom -52px). Label "ACTIVE FILTERS" is 700 10.5px `#0C7F88`.
  - Pills: 26px tall, bg `#EAF7F8`, text `#0B3A50`, each with a ✕ clear button. The date-range pill can't be cleared.
  - "Reset all" link appears when any filter is active.
- **Filter bar** (sticky, white, padding 40px 32px 14px): **5-column grid** with 12px gaps. Competitor spans 2 columns, so the filters form two rows of five slots.
  - Filters, in order: Competitor, Macrotrend, Subtrend, Growth intensity, Impact, Source, Action, Date from, Date to.
  - Labels: 600 10px uppercase, .1em, `#587080`.
  - Selects/inputs: 34px tall, radius 6, border `#CFDCE3`. When a filter is active its border becomes `#1FA7B0` and its bg `#EAF7F8`.
  - The Subtrend options narrow to the chosen Macrotrend.
- **Signal Timeline** card: 120px label column + plot 260px tall with a `#FAFCFD` background.
  - Y axis = growth intensity levels. X axis = date range, with month ticks in IBM Plex Mono 11px.
  - Point shape encodes impact: Low is a 10px circle `#3A9A5F`, Medium a 12px square `#F0A650`, High a 14px diamond `#C8413A`. Points have a white 1.5px border.
  - Hover shows a navy tooltip (280px) with title, competitors, date, impact and growth. Clicking a point opens the record drawer.
- **Chart grid**: auto-fit minmax(460px,1fr), gap 20, rows stretch to equal height.
  1. Signals by Macrotrend: bars in `#1C9CA5`.
  2. Impact mix by Macrotrend: stacked High `#C8413A`, Medium `#F0A650`, Low `#3A9A5F`, with an "H / M / L" count on the right.
  3. Signals by Subtrend.
  4. Impact mix by Subtrend.
  5. Competitor composition: **spans the full row** (grid-column 1 / -1), bars in `#2A7FC4`. The footnote explains that multi-competitor items make the counts sum higher than the item count.
  - Row layout: 200px label | bar | count (IBM Plex Mono 12px). Bar track is `#EEF3F6`, radius 3.
  - Each chart ignores its own dimension's filter (noted in its subtitle).

### 2. Tracker
- The header, filters card and filter bar are the same as the Dashboard, without the KPIs. H1 is "TRACKER".
- **Table card**: the top row shows "Showing a–b of n · page x of y" and an **Export** button (teal `#0C7F88`, hover `#096A72`, 36px, radius 7).
- **Export popover** (300px):
  - Rows toggle: Filtered (n) or All (n), as a segmented control.
  - Formats: CSV (UTF-8 BOM), Excel .xlsx (SheetJS; column widths auto-fit), TSV, JSON.
  - Export includes Signal ID plus every current column, in the current sort order. Filename: `eradigm-tracker-{filtered|all}-YYYY-MM-DD.ext`.
- **Table**: columns come from the schema, so they are dynamic.
  - Header row: bg `#F3F7F9`, 600 10px uppercase. Click a header to sort; a second click reverses.
  - Rows: 11px padding, row border `#E8EEF1`, hover `#F2FAFA`. Click a row to open the record drawer.
  - Date cells use IBM Plex Mono 12px. Competitor cells are bold.
  - Growth shows a glyph (— / ▲ / ▲▲).
  - Impact renders as a pill: Low bg `#E7F4EC` text `#2E7A4B`, Medium bg `#FCF0E0` text `#A55F12`, High bg `#F9E6E4` text `#A5302A`.
  - Action shows ✓ in green `#2E7A4B` for Actioned and ○ in grey for Not Actioned.
  - 10 rows per page, with Previous/Next.
- **Record drawer**: right side, 640px, backdrop `rgba(7,40,56,.42)`. Sections: title + text, Classifications (2-col grid), Company associations (navy pills), Source and snapshot, Provenance, Analyst revision history (timeline) and Related signals.

### 3. Inbox
- **Header**: eyebrow "{n} AWAITING REVIEW · {n} APPROVED TODAY", H1 "INBOX", plus explanatory copy on the right.
- **Tracker columns editor** (Inbox only): an "Edit columns" button toggles a table with the headings #, Column name, Type, Dropdown options, Entry and Delete.
  - **Rename a column**: edit the input inline; the change commits on blur or Enter.
  - **Required/Optional toggle**: controls approval validation.
  - **Delete a column**: two-step (click Delete, then "Confirm delete" within 4s). These chart-critical core columns are locked: Date, Competitor, Macrotrend, Subtrend, News title, Growth intensity, Impact. They can be renamed but not deleted.
  - **Dropdown options**: expandable per column. You can rename (renames propagate to all signals, drafts and filters), delete (blocked while any published signal uses the option; shows "n in use") and add.
  - **Subtrend options** are edited in groups under each Macrotrend.
  - **Add column**: name + type (Dropdown / Text / Date). New columns start Optional.
  - Duplicate names are rejected with a toast.
- **Inbox cards**: an expand toggle reveals the source HTML snapshot. The card header shows ID · outlet · received time and the title. Items from Input show an "LLM draft · n warnings" tag (amber).
  - **Tracker draft**: a one-row editable table generated from the schema (date input, text inputs, selects). Required empty fields have an amber border `#E0A05A`. Failed validation turns them red `#C8413A` and shows a message listing the missing fields.
  - **✓ Approve**: validates the draft, then publishes to the Tracker as rev 1 and shows reviewer + time. The card border turns `#BFE0CB` and a toast appears.

### 4. Input (analyst/admin only; viewers see neither the nav item nor the page)
- **Header**: eyebrow "ANALYSTS AND ADMINS ONLY", H1 "INPUT", plus explanatory copy. The page scrolls normally.
- **New source card**: segmented URL / HTML file toggle.
  - URL mode: monospace input + "Capture source" button. Sample chips: Public article, Private IP, Metadata, Paywall, FTP.
  - File mode: dashed drop label (`#9FD8DC` on `#F6FBFB`). Accepts only .html/.htm up to 10 MB and detects SingleFile metadata (the original URL).
- **Capture and extraction card**: an 8-step pipeline animated at 420ms per step. Step states are waiting / in progress / ✓ done (`#1C9CA5`) / ✕ failed (`#C8413A`) / not run. The pipeline stops at the first failed check.
  - URL pipeline: Validate and normalise → Destination check → Isolated capture worker → Access restrictions → Content scan → Minimum extraction to LLM → Schema-constrained classification → Routed to Needs review.
- **Model output card**: a table with Field, Value (or `null`), Confidence (bar + %; amber below 65%), Evidence excerpt (italic) and Validation (warnings in amber, "Passed" in green). "Review in Inbox →" button.
- **Capture log**: Time, Submitted, Final resolved URL, Outcome (✓ green / ✕ red).

## Security and pipeline requirements (implement server-side)
- Accept HTTP/HTTPS only. Normalise the URL: add a scheme if missing, strip the fragment, strip tracking params (`utm_*`, `fbclid`, `gclid`, `mc_*`, `igshid`, `ref`) and reject embedded credentials.
- Block private, loopback, link-local (including 169.254.169.254 metadata), CGNAT, multicast/reserved, IPv6 ULA/link-local/loopback, IPv4-mapped and internal hostnames. **Re-check after DNS resolution and after every redirect.**
- Limits: max 5 redirects, 10 MB, 20 s page load (30 s job); accept text/html only.
- Scan content before storage. Strip scripts, trackers and forms. Store the snapshot immutably.
- Capture in an isolated worker (headless Chromium + SingleFile) with no access to the app database or secrets, egress through a filtering proxy and no persistent cookies/profile. Log the final resolved URL and outcome for every submission.
- Respect logins, paywalls, robots.txt and technical protections, and never bypass them. On a block, stop and tell the analyst to upload a SingleFile HTML saved in their own browser.
- Verify that the chosen Cloudflare service supports the browser runtime, script injection and snapshot filesystem. If it doesn't, run the capture worker in a separate container and keep the public app on Cloudflare.
- Send the LLM only the headline, body text, publication date and current taxonomy lists. Never send raw HTML, images, cookies or query strings.
- LLM output must be JSON constrained to the tracker schema, with explicit nulls, an evidence excerpt and a confidence value per field, plus validation warnings. Any value outside the current taxonomy is dropped to null with a warning; the model can never create taxonomy values.
- **Every** LLM draft goes to Needs review (the Inbox). Nothing is auto-published.

## State / data model
- `columns[]`: `{key, label, type: date|multi|macro|sub|text|select, opts?, core?, req}`.
- `taxonomy`: `{ [macrotrend]: subtrend[] }`.
- `signals[]`: `{id, ...columnValues, text, url, inboxId, revs[{rev, who, when, note}]}`. Competitor is an array.
- `inbox[]`: `{id, received, outlet, url, html snapshot, draft values, approved?, llm{warnings}}`.
- `captureLog[]`: `{time, input, finalUrl, outcome, ok}`.
- UI state: view, filters `{colKey: value, from, to, q}`, sort `{k, d}`, page, selected record, sidebar open, export scope.
- Roles: `viewer` (read-only Dashboard/Tracker/Inbox), `analyst` and `admin` (Input + approve + schema edits).
- A rename propagates to all signals, drafts and active filters. A deleted option clears it from drafts and filters.

## Design tokens
- **Navy**: `#072838` (sidebar, tooltip, toast), `#082C3D`, `#0B3A50`, `#0F4C66` (header gradient).
- **Teal (primary)**: `#0C7F88`, hover `#096A72`.
- **Chart teal**: `#1C9CA5`. **Focus/active border**: `#1FA7B0`. **Cyan highlight**: `#3DC3C9`, `#7FD3D8`.
- **Tint**: `#EAF7F8`, `#F2FAFA`, `#F6FBFB`. **Dashed accent border**: `#9FD8DC`.
- **Ink**: `#14303D`. **Secondary text**: `#35505C`. **Muted text**: `#587080`, `#7E95A1`, `#9AB0BB`. **On-dark muted**: `#B5CFDA`, `#8FB4C4`, `#C9DCE4`, `#6F97A8`.
- **Surfaces**: page `#EEF3F6`, white, table header `#F3F7F9`, subtle `#F6F9FA`, plot `#FAFCFD`.
- **Borders**: `#DCE5EA` (cards), `#CFDCE3` (inputs), `#E8EEF1` (row rules), `#C3D2DA` (axes).
- **Impact**: Low `#3A9A5F`, Medium `#F0A650`, High `#C8413A`.
- **Status**: success `#2E8352`/`#2E7A4B`, error text `#B0322A`, warning text `#A55F12`.
- **Competitor bars**: `#2A7FC4`.
- **Type**: Nunito Sans (400–800; opsz 6..12) for everything. IBM Plex Mono 400/500 for IDs, dates, counts and URLs.
  - Type scale (px): 10 (labels, uppercase, .1–.14em), 12, 12.5, 13, 13.5, 14, 15.5, 20, 28 (H1), 58 (KPI).
- **Radii**: 5–6 (inputs), 7 (buttons), 8, 10 (cards), 12 (logo), pills 10–14.
- **Shadows**: filter card `0 6px 18px rgba(7,40,56,.16)`, popover `0 12px 32px rgba(7,40,56,.18)`, drawer `-12px 0 32px rgba(7,40,56,.2)`, sticky bar `0 4px 14px rgba(7,40,56,.06)`.
- **Focus ring**: 2px `#1FA7B0`, offset 1px.

## Assets
- `assets/eradigm-logo.webp`: the Eradigm logo.
- Fonts from Google Fonts: Nunito Sans, IBM Plex Mono.
- The Excel export uses SheetJS (`xlsx` 0.20.x).

## Files
- `Intelligence Dashboard.dc.html`: the full prototype (template + logic class with mock data, schema editor, export, capture pipeline simulation).
- `support.js`: the runtime needed to open the prototype in a browser. It is not part of the product.
- `assets/`: logo.
